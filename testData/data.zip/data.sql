/*
Navicat MySQL Data Transfer

Source Server         : 192.168.253.100
Source Server Version : 50649
Source Host           : 192.168.253.100:3306
Source Database       : trace

Target Server Type    : MYSQL
Target Server Version : 50649
File Encoding         : 65001

Date: 2020-10-13 05:33:46
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for data
-- ----------------------------
DROP TABLE IF EXISTS `data`;
CREATE TABLE `data` (
  `GID` int(11) NOT NULL AUTO_INCREMENT,
  `PATROLERID` int(10) NOT NULL,
  `UPTIME` datetime NOT NULL,
  `PATROLTRACE1` text NOT NULL,
  `PATROLTRACE2` text NOT NULL,
  PRIMARY KEY (`GID`)
) ENGINE=InnoDB AUTO_INCREMENT=150072 DEFAULT CHARSET=utf8;
